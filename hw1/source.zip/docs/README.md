
Homework 1 Lexical Analyzer
------------------
Group name   : CL

Group member: Zheyang Li

Documents in answers/docs folder:

1. Design Document 

2. Code Review Document 